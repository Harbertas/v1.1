var files_dup =
[
    [ "functions.cpp", "functions_8cpp.html", "functions_8cpp" ],
    [ "functions.h", "functions_8h.html", "functions_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];