var classzmogus =
[
    [ "zmogus", "classzmogus.html#ad903f854be07c672868f75d3c02f1d66", null ],
    [ "pavarde", "classzmogus.html#aaa7462a96db6e69b3cec33be0e02c2d3", null ],
    [ "setPavarde", "classzmogus.html#a33e3eb561d04e5eb0ee5a00de3b9f8e0", null ],
    [ "setVardas", "classzmogus.html#acacdb2524e91d2462d767e9208439717", null ],
    [ "vardas", "classzmogus.html#a3c272bfac2ad007b42372c2934c39ee9", null ],
    [ "pavarde_", "classzmogus.html#a4df33c060374e0a9853d3fda824f0deb", null ],
    [ "vardas_", "classzmogus.html#ad20a48c056323b41af24f6891e671404", null ]
];