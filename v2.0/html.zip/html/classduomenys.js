var classduomenys =
[
    [ "duomenys", "classduomenys.html#aab92be91aa16c17222f48a606dbe158d", null ],
    [ "~duomenys", "classduomenys.html#a312c1fcccbcaea0499e4b86eb9ebd162", null ],
    [ "duomenys", "classduomenys.html#aa522adf3393fa2b33adb398611353771", null ],
    [ "egz", "classduomenys.html#a463c7f221111350ddb5ae742b9258aab", null ],
    [ "getPaz", "classduomenys.html#a0d4f0b109b023d1a654af0d941925924", null ],
    [ "kiekPaz", "classduomenys.html#a41ccd034bc6d2966057669917ce7cdd7", null ],
    [ "mediana", "classduomenys.html#a4b8f5c542c49c382041a74439c4ea338", null ],
    [ "operator=", "classduomenys.html#a3b71e207a18a5bedf02d0a61c3cc4152", null ],
    [ "readStudent", "classduomenys.html#a97383b603b3f60f07b9d34e469a1bf5c", null ],
    [ "rezult", "classduomenys.html#ad3e9bc5ffe9179e3122db650dc2b78dc", null ],
    [ "setEgz", "classduomenys.html#aab56505c61bd753dbb58a831e250de74", null ],
    [ "setKiekPaz", "classduomenys.html#a6c83a1fcae9dbcdefc6da9c90cb2f8cb", null ],
    [ "setPavarde", "classduomenys.html#ad612a24918bd8340c0d7adb69ecbd261", null ],
    [ "setPaz", "classduomenys.html#a0ef706ca53ec60396a2f697153be671a", null ],
    [ "setRezult", "classduomenys.html#a2f58ed6ec2064f004a452b038c84b587", null ],
    [ "setVardas", "classduomenys.html#a05caad10cbbdfd3b575e10274d253e12", null ],
    [ "skaiciuoti", "classduomenys.html#a3410eed1efcc78da51bfb2bcfa7d8964", null ],
    [ "operator<<", "classduomenys.html#a2f3a53d19256d7f2031c7fb6a3696319", null ]
];