var hierarchy =
[
    [ "zmogus", "classzmogus.html", [
      [ "duomenys", "classduomenys.html", null ]
    ] ]
];