var searchData=
[
  ['pavarde_0',['pavarde',['../classzmogus.html#aaa7462a96db6e69b3cec33be0e02c2d3',1,'zmogus']]]
];
