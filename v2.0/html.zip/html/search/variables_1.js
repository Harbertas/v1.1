var searchData=
[
  ['vardas_5f_0',['vardas_',['../classzmogus.html#ad20a48c056323b41af24f6891e671404',1,'zmogus']]]
];
