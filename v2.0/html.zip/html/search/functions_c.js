var searchData=
[
  ['vardas_0',['vardas',['../classzmogus.html#a3c272bfac2ad007b42372c2934c39ee9',1,'zmogus']]]
];
