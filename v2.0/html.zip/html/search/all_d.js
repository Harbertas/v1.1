var searchData=
[
  ['vardas_0',['vardas',['../classzmogus.html#a3c272bfac2ad007b42372c2934c39ee9',1,'zmogus']]],
  ['vardas_5f_1',['vardas_',['../classzmogus.html#ad20a48c056323b41af24f6891e671404',1,'zmogus']]]
];
