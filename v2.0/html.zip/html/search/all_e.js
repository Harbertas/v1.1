var searchData=
[
  ['zmogus_0',['zmogus',['../classzmogus.html',1,'zmogus'],['../classzmogus.html#ad903f854be07c672868f75d3c02f1d66',1,'zmogus::zmogus()']]]
];
