var searchData=
[
  ['_7eduomenys_0',['~duomenys',['../classduomenys.html#a312c1fcccbcaea0499e4b86eb9ebd162',1,'duomenys']]]
];
