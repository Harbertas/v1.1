var searchData=
[
  ['setegz_0',['setEgz',['../classduomenys.html#aab56505c61bd753dbb58a831e250de74',1,'duomenys']]],
  ['setkiekpaz_1',['setKiekPaz',['../classduomenys.html#a6c83a1fcae9dbcdefc6da9c90cb2f8cb',1,'duomenys']]],
  ['setpavarde_2',['setPavarde',['../classzmogus.html#a33e3eb561d04e5eb0ee5a00de3b9f8e0',1,'zmogus::setPavarde()'],['../classduomenys.html#ad612a24918bd8340c0d7adb69ecbd261',1,'duomenys::setPavarde(string p)']]],
  ['setpaz_3',['setPaz',['../classduomenys.html#a0ef706ca53ec60396a2f697153be671a',1,'duomenys']]],
  ['setrezult_4',['setRezult',['../classduomenys.html#a2f58ed6ec2064f004a452b038c84b587',1,'duomenys']]],
  ['setvardas_5',['setVardas',['../classzmogus.html#acacdb2524e91d2462d767e9208439717',1,'zmogus::setVardas()'],['../classduomenys.html#a05caad10cbbdfd3b575e10274d253e12',1,'duomenys::setVardas(string v)']]],
  ['skaiciuoti_6',['skaiciuoti',['../classduomenys.html#a3410eed1efcc78da51bfb2bcfa7d8964',1,'duomenys']]],
  ['spausdinti_7',['spausdinti',['../functions_8cpp.html#a427607295a619cddc8c09cbef85a6858',1,'spausdinti(vector&lt; duomenys &gt; &amp;sarasas, vector&lt; duomenys &gt; &amp;sarasas2, int fileLength):&#160;functions.cpp'],['../functions_8h.html#a2111a7f7a0347f3aa549a7bb6e87436c',1,'spausdinti(vector&lt; duomenys &gt; &amp;, vector&lt; duomenys &gt; &amp;, int):&#160;functions.cpp']]]
];
